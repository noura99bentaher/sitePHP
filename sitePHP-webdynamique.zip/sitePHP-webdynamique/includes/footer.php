<!doctype html>

<html>

<head>

<meta charset="UTF-8">


<style>

*{

margin:0;

padding:0;

}

 

body, html{height:100%;}

body{

text-align:center;

}

 

#main{

max-width:1280px;

min-height:100%;

margin:0 auto;

position:relative;

}

 p{
     background:#ccc;
 }

footer{

background:#ccc;

position:absolute;

bottom:0;

width:100%;

padding-top:50px;

height:50px;

}
</style>

</head>

<body>

<div id="main">

<header>

</header>

<section>

</section>

<footer>
<p> Spring Our Online Store <br> 
Copyright &copy; 2020</p>

</footer>

</div>

</body>

</html>

 



 

